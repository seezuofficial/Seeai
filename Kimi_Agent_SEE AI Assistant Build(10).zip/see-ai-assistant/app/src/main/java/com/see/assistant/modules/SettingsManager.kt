package com.see.assistant.modules

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.see.assistant.utils.Logger
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "see_settings")

/**
 * SettingsManager - User preferences aur customization ka manager
 * 
 * Ismein saari user settings store hoti hain:
 * - Assistant name
 * - Voice style
 * - Tone/Personality
 * - Theme
 * - Language
 * - Pro mode
 */
class SettingsManager(private val context: Context) {
    
    private val TAG = "SettingsManager"
    private val dataStore = context.dataStore
    
    // Preference Keys
    companion object Keys {
        // Basic Settings
        val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
        val USER_NAME = stringPreferencesKey("user_name")
        val VOICE_STYLE = stringPreferencesKey("voice_style")
        val TONE = stringPreferencesKey("tone")
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
        
        // Feature Toggles
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val OFFLINE_MODE = booleanPreferencesKey("offline_mode")
        val PRO_MODE = booleanPreferencesKey("pro_mode")
        val FLOATING_UI_ENABLED = booleanPreferencesKey("floating_ui_enabled")
        val AUTO_START = booleanPreferencesKey("auto_start")
        
        // Wake Word Settings
        val WAKE_WORD_SENSITIVITY = floatPreferencesKey("wake_word_sensitivity")
        val WAKE_WORD_PHRASE = stringPreferencesKey("wake_word_phrase")
        
        // Voice Recognition
        val SPEECH_LANGUAGE = stringPreferencesKey("speech_language")
        val PREFERRED_RECOGNIZER = stringPreferencesKey("preferred_recognizer")
        
        // TTS Settings
        val TTS_SPEED = floatPreferencesKey("tts_speed")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        
        // Notification Settings
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val READ_NOTIFICATIONS_ALOUD = booleanPreferencesKey("read_notifications_aloud")
        
        // Privacy
        val STORE_CONVERSATIONS = booleanPreferencesKey("store_conversations")
        val SHARE_USAGE_DATA = booleanPreferencesKey("share_usage_data")
    }
    
    // Default Values
    object Defaults {
        const val ASSISTANT_NAME = "SEE"
        const val USER_NAME = "Seezuu"
        const val VOICE_STYLE = "female"
        const val TONE = "friendly"
        const val THEME = "dark"
        const val LANGUAGE = "hinglish"
        const val WAKE_WORD_PHRASE = "hey see"
        const val SPEECH_LANGUAGE = "hi-IN"
        const val PREFERRED_RECOGNIZER = "auto"
        const val WAKE_WORD_SENSITIVITY = 0.7f
        const val TTS_SPEED = 1.0f
        const val TTS_PITCH = 1.0f
    }
    
    suspend fun initialize() {
        Logger.d(TAG, "⚙️ Initializing SettingsManager")
        // Set defaults if first run
        val isFirstRun = dataStore.data.first()[ASSISTANT_NAME] == null
        if (isFirstRun) {
            setDefaults()
        }
    }
    
    private suspend fun setDefaults() {
        Logger.d(TAG, "📝 Setting default preferences")
        dataStore.edit { prefs ->
            prefs[ASSISTANT_NAME] = Defaults.ASSISTANT_NAME
            prefs[USER_NAME] = Defaults.USER_NAME
            prefs[VOICE_STYLE] = Defaults.VOICE_STYLE
            prefs[TONE] = Defaults.TONE
            prefs[THEME] = Defaults.THEME
            prefs[LANGUAGE] = Defaults.LANGUAGE
            prefs[WAKE_WORD_ENABLED] = true
            prefs[OFFLINE_MODE] = false
            prefs[PRO_MODE] = false
            prefs[FLOATING_UI_ENABLED] = true
            prefs[AUTO_START] = true
            prefs[WAKE_WORD_SENSITIVITY] = Defaults.WAKE_WORD_SENSITIVITY
            prefs[WAKE_WORD_PHRASE] = Defaults.WAKE_WORD_PHRASE
            prefs[SPEECH_LANGUAGE] = Defaults.SPEECH_LANGUAGE
            prefs[PREFERRED_RECOGNIZER] = Defaults.PREFERRED_RECOGNIZER
            prefs[TTS_SPEED] = Defaults.TTS_SPEED
            prefs[TTS_PITCH] = Defaults.TTS_PITCH
            prefs[NOTIFICATIONS_ENABLED] = true
            prefs[READ_NOTIFICATIONS_ALOUD] = false
            prefs[STORE_CONVERSATIONS] = true
            prefs[SHARE_USAGE_DATA] = false
        }
    }
    
    // ==================== GETTERS ====================
    
    fun getAssistantName(): Flow<String> = 
        dataStore.data.map { it[ASSISTANT_NAME] ?: Defaults.ASSISTANT_NAME }
    
    fun getUserName(): Flow<String> = 
        dataStore.data.map { it[USER_NAME] ?: Defaults.USER_NAME }
    
    fun getVoiceStyle(): Flow<String> = 
        dataStore.data.map { it[VOICE_STYLE] ?: Defaults.VOICE_STYLE }
    
    fun getTone(): Flow<String> = 
        dataStore.data.map { it[TONE] ?: Defaults.TONE }
    
    fun getTheme(): Flow<String> = 
        dataStore.data.map { it[THEME] ?: Defaults.THEME }
    
    fun getLanguage(): Flow<String> = 
        dataStore.data.map { it[LANGUAGE] ?: Defaults.LANGUAGE }
    
    fun isWakeWordEnabled(): Flow<Boolean> = 
        dataStore.data.map { it[WAKE_WORD_ENABLED] ?: true }
    
    fun isOfflineMode(): Flow<Boolean> = 
        dataStore.data.map { it[OFFLINE_MODE] ?: false }
    
    fun isProMode(): Flow<Boolean> = 
        dataStore.data.map { it[PRO_MODE] ?: false }
    
    fun isFloatingUIEnabled(): Flow<Boolean> = 
        dataStore.data.map { it[FLOATING_UI_ENABLED] ?: true }
    
    fun getWakeWordSensitivity(): Flow<Float> = 
        dataStore.data.map { it[WAKE_WORD_SENSITIVITY] ?: Defaults.WAKE_WORD_SENSITIVITY }
    
    fun getWakeWordPhrase(): Flow<String> = 
        dataStore.data.map { it[WAKE_WORD_PHRASE] ?: Defaults.WAKE_WORD_PHRASE }
    
    fun getTtsSpeed(): Flow<Float> = 
        dataStore.data.map { it[TTS_SPEED] ?: Defaults.TTS_SPEED }
    
    fun getTtsPitch(): Flow<Float> = 
        dataStore.data.map { it[TTS_PITCH] ?: Defaults.TTS_PITCH }
    
    // Synchronous getters (for immediate use)
    fun getUserNameSync(): String = runBlocking { getUserName().first() }
    fun getAssistantNameSync(): String = runBlocking { getAssistantName().first() }
    fun getToneSync(): String = runBlocking { getTone().first() }
    fun getLanguageSync(): String = runBlocking { getLanguage().first() }
    fun isProModeSync(): Boolean = runBlocking { isProMode().first() }
    
    // ==================== SETTERS ====================
    
    suspend fun setAssistantName(name: String) {
        dataStore.edit { it[ASSISTANT_NAME] = name }
        Logger.d(TAG, "Assistant name changed to: $name")
    }
    
    suspend fun setUserName(name: String) {
        dataStore.edit { it[USER_NAME] = name }
        Logger.d(TAG, "User name changed to: $name")
    }
    
    suspend fun setVoiceStyle(style: String) {
        dataStore.edit { it[VOICE_STYLE] = style }
        Logger.d(TAG, "Voice style changed to: $style")
    }
    
    suspend fun setTone(tone: String) {
        dataStore.edit { it[TONE] = tone }
        Logger.d(TAG, "Tone changed to: $tone")
    }
    
    suspend fun setTheme(theme: String) {
        dataStore.edit { it[THEME] = theme }
        Logger.d(TAG, "Theme changed to: $theme")
    }
    
    suspend fun setLanguage(language: String) {
        dataStore.edit { it[LANGUAGE] = language }
        Logger.d(TAG, "Language changed to: $language")
    }
    
    suspend fun setWakeWordEnabled(enabled: Boolean) {
        dataStore.edit { it[WAKE_WORD_ENABLED] = enabled }
        Logger.d(TAG, "Wake word enabled: $enabled")
    }
    
    suspend fun setOfflineMode(enabled: Boolean) {
        dataStore.edit { it[OFFLINE_MODE] = enabled }
        Logger.d(TAG, "Offline mode: $enabled")
    }
    
    suspend fun setProMode(enabled: Boolean) {
        dataStore.edit { it[PRO_MODE] = enabled }
        Logger.d(TAG, "Pro mode: $enabled")
    }
    
    suspend fun setFloatingUIEnabled(enabled: Boolean) {
        dataStore.edit { it[FLOATING_UI_ENABLED] = enabled }
        Logger.d(TAG, "Floating UI: $enabled")
    }
    
    suspend fun setWakeWordSensitivity(sensitivity: Float) {
        dataStore.edit { it[WAKE_WORD_SENSITIVITY] = sensitivity.coerceIn(0.1f, 1.0f) }
    }
    
    suspend fun setWakeWordPhrase(phrase: String) {
        dataStore.edit { it[WAKE_WORD_PHRASE] = phrase.lowercase() }
    }
    
    suspend fun setTtsSpeed(speed: Float) {
        dataStore.edit { it[TTS_SPEED] = speed.coerceIn(0.5f, 2.0f) }
    }
    
    suspend fun setTtsPitch(pitch: Float) {
        dataStore.edit { it[TTS_PITCH] = pitch.coerceIn(0.5f, 2.0f) }
    }
    
    // ==================== PERSONALITY RESPONSES ====================
    
    fun getResponseForAction(action: String): String {
        val tone = runBlocking { getTone().first() }
        val userName = runBlocking { getUserName().first() }
        
        return when (tone) {
            "friendly" -> getFriendlyResponse(action, userName)
            "funny" -> getFunnyResponse(action, userName)
            "romantic" -> getRomanticResponse(action, userName)
            "professional" -> getProfessionalResponse(action, userName)
            else -> getFriendlyResponse(action, userName)
        }
    }
    
    private fun getFriendlyResponse(action: String, userName: String): String {
        return when (action) {
            "flashlight_on" -> "Done $userName 😊 flashlight on kar diya"
            "flashlight_off" -> "Flashlight band kar diya $userName"
            "wifi_on" -> "WiFi on ho gaya $userName 📶"
            "wifi_off" -> "WiFi band kar diya"
            "bluetooth_on" -> "Bluetooth connected! 🎧"
            "bluetooth_off" -> "Bluetooth off ho gaya"
            "volume_up" -> "Volume badha diya 🔊"
            "volume_down" -> "Volume kam kar diya 🔉"
            "success" -> "Ho gaya $userName! ✅"
            "error" -> "Arre kuch problem ho gayi, dobara try karo 😅"
            "listening" -> "Haan $userName, boliye..."
            "welcome" -> "Hello $userName! Main ready hoon 🚀"
            else -> "Done $userName! 👍"
        }
    }
    
    private fun getFunnyResponse(action: String, userName: String): String {
        return when (action) {
            "flashlight_on" -> "Andhera bhagao, flashlight aa gaya! 💡"
            "flashlight_off" -> "Bachat mode on, flashlight band! 😎"
            "wifi_on" -> "Internet ki ganga bah rahi hai! 🌊"
            "wifi_off" -> "Digital detox time! 📵"
            "success" -> "Kaam ho gaya boss! 🎯"
            "error" -> "Oops! Kuch gadbad ho gayi 😂"
            "listening" -> "Kaan laga ke sun raha hoon... 👂"
            else -> "Ho gaya $userName, ab party? 🎉"
        }
    }
    
    private fun getRomanticResponse(action: String, userName: String): String {
        return when (action) {
            "flashlight_on" -> "Roshni aa gayi jaise tumhari smile 💫"
            "success" -> "Tumhare liye kuch bhi $userName ❤️"
            "listening" -> "Haan jaan, bolo..."
            "welcome" -> "Tumhari yaad aa rahi thi, $userName 💕"
            else -> "Done jaan, aur kuch?"
        }
    }
    
    private fun getProfessionalResponse(action: String, userName: String): String {
        return when (action) {
            "flashlight_on" -> "Flashlight activated."
            "flashlight_off" -> "Flashlight deactivated."
            "wifi_on" -> "WiFi connection enabled."
            "wifi_off" -> "WiFi connection disabled."
            "success" -> "Task completed successfully."
            "error" -> "An error occurred. Please retry."
            "listening" -> "I'm listening, $userName."
            "welcome" -> "System ready. Awaiting commands."
            else -> "Executed."
        }
    }
}

// Voice Styles
object VoiceStyles {
    const val MALE = "male"
    const val FEMALE = "female"
    const val ROBOTIC = "robotic"
}

// Tones/Personalities
object Tones {
    const val FRIENDLY = "friendly"
    const val FUNNY = "funny"
    const val ROMANTIC = "romantic"
    const val PROFESSIONAL = "professional"
}

// Themes
object Themes {
    const val DARK = "dark"
    const val LIGHT = "light"
    const val NEON = "neon"
}

// Languages
object Languages {
    const val HINDI = "hindi"
    const val ENGLISH = "english"
    const val HINGLISH = "hinglish"
    const val JAPANESE = "japanese"
}
