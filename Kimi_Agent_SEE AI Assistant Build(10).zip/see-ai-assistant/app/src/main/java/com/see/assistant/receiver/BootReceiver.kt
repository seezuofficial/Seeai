package com.see.assistant.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.see.assistant.modules.SettingsManager
import com.see.assistant.service.SEECoreService
import com.see.assistant.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * BootReceiver - Phone restart hone par service start karta hai
 */
class BootReceiver : BroadcastReceiver() {
    
    private val TAG = "BootReceiver"
    
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            
            Logger.i(TAG, "📱 Boot completed, checking auto-start settings")
            
            CoroutineScope(Dispatchers.Default).launch {
                try {
                    // Check if auto-start is enabled
                    val settingsManager = SettingsManager(context)
                    val autoStart = settingsManager.isWakeWordEnabled().first()
                    
                    if (autoStart) {
                        Logger.i(TAG, "🚀 Auto-starting SEE service")
                        SEECoreService.startService(context)
                    } else {
                        Logger.d(TAG, "Auto-start disabled, skipping")
                    }
                } catch (e: Exception) {
                    Logger.e(TAG, "Error during auto-start", e)
                }
            }
        }
    }
}
