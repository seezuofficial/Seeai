package com.see.assistant.receiver

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.see.assistant.CHANNEL_REMINDERS
import com.see.assistant.R
import com.see.assistant.SEEApplication
import com.see.assistant.modules.TextToSpeechModule
import com.see.assistant.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AlarmReceiver - Alarms aur reminders ke liye
 */
class AlarmReceiver : BroadcastReceiver() {
    
    private val TAG = "AlarmReceiver"
    
    override fun onReceive(context: Context, intent: Intent) {
        val message = intent.getStringExtra("message") ?: "Reminder"
        
        Logger.i(TAG, "⏰ Alarm received: $message")
        
        // Vibrate
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            vibrator.vibrate(
                android.os.VibrationEffect.createWaveform(
                    longArrayOf(0, 500, 200, 500, 200, 500),
                    -1
                )
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 500, 200, 500, 200, 500), -1)
        }
        
        // Show notification
        showNotification(context, message)
        
        // Speak reminder
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val tts = SEEApplication.getInstance().textToSpeechModule
                tts.speak("Reminder: $message")
            } catch (e: Exception) {
                Logger.e(TAG, "TTS failed", e)
            }
        }
    }
    
    private fun showNotification(context: Context, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setContentTitle("SEE Reminder")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_alarm)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            .setVibrate(longArrayOf(0, 500, 200, 500))
            .setAutoCancel(true)
            .build()
        
        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
