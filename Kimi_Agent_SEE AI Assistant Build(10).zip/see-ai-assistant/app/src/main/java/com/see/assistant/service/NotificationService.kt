package com.see.assistant.service

import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.see.assistant.SEEApplication
import com.see.assistant.modules.TextToSpeechModule
import com.see.assistant.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * NotificationService - Notifications read karne ke liye
 * 
 * Features:
 * - Listen for new notifications
 * - Read notifications aloud (if enabled)
 * - Store notification history
 * - Reply to notifications
 */
class NotificationService : NotificationListenerService() {
    
    private val TAG = "NotificationService"
    
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var textToSpeech: TextToSpeechModule
    
    // Track which apps to read notifications from
    private val allowedApps = mutableSetOf(
        "com.whatsapp",
        "com.facebook.katana",
        "com.instagram.android",
        "com.google.android.gm",
        "com.google.android.apps.messaging",
        "com.android.dialer"
    )
    
    // Blocked apps (don't read from these)
    private val blockedApps = mutableSetOf(
        "android",
        "com.android.systemui"
    )
    
    companion object {
        var instance: NotificationService? = null
            private set
        
        fun isRunning(): Boolean = instance != null
        
        const val ACTION_READ_NOTIFICATIONS = "com.see.assistant.READ_NOTIFICATIONS"
        const val ACTION_CLEAR_NOTIFICATIONS = "com.see.assistant.CLEAR_NOTIFICATIONS"
    }
    
    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_READ_NOTIFICATIONS -> readAllNotifications()
                ACTION_CLEAR_NOTIFICATIONS -> cancelAllNotifications()
            }
        }
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        Logger.i(TAG, "🔔 NotificationService created")
        
        textToSpeech = SEEApplication.getInstance().textToSpeechModule
        
        // Register command receiver
        val filter = IntentFilter().apply {
            addAction(ACTION_READ_NOTIFICATIONS)
            addAction(ACTION_CLEAR_NOTIFICATIONS)
        }
        registerReceiver(commandReceiver, filter)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        instance = null
        unregisterReceiver(commandReceiver)
        Logger.i(TAG, "👋 NotificationService destroyed")
    }
    
    override fun onListenerConnected() {
        super.onListenerConnected()
        Logger.i(TAG, "✅ Notification listener connected")
    }
    
    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Logger.w(TAG, "⚠️ Notification listener disconnected")
    }
    
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        
        val packageName = sbn.packageName
        
        // Skip blocked apps
        if (blockedApps.contains(packageName)) return
        
        val notification = sbn.notification
        val title = notification.extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val bigText = notification.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: text
        
        Logger.d(TAG, "📩 Notification from $packageName: $title - $text")
        
        // Check if we should read aloud
        serviceScope.launch {
            val settings = SEEApplication.getInstance().settingsManager
            val readAloud = settings.getReadNotificationsAloud().first()
            
            if (readAloud && allowedApps.contains(packageName)) {
                val message = "Notification from ${getAppName(packageName)}: $title. $text"
                textToSpeech.speak(message)
            }
        }
        
        // Store in memory
        serviceScope.launch {
            val memoryManager = SEEApplication.getInstance().memoryManager
            // Could store notification history here
        }
    }
    
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        Logger.d(TAG, "🗑️ Notification removed: ${sbn.packageName}")
    }
    
    // ==================== PUBLIC METHODS ====================
    
    fun readAllNotifications() {
        val notifications = activeNotifications
        
        if (notifications.isEmpty()) {
            textToSpeech.speak("Koi notification nahi hai")
            return
        }
        
        val summary = buildString {
            append("Aapke paas ${notifications.size} notifications hain. ")
            
            notifications.take(5).forEach { sbn ->
                val title = sbn.notification.extras.getString(Notification.EXTRA_TITLE) ?: "Unknown"
                val appName = getAppName(sbn.packageName)
                append("$appName se: $title. ")
            }
        }
        
        textToSpeech.speak(summary)
    }
    
    fun getUnreadNotifications(): List<NotificationInfo> {
        return activeNotifications.map { sbn ->
            NotificationInfo(
                id = sbn.id,
                packageName = sbn.packageName,
                appName = getAppName(sbn.packageName),
                title = sbn.notification.extras.getString(Notification.EXTRA_TITLE) ?: "",
                text = sbn.notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "",
                postTime = sbn.postTime
            )
        }
    }
    
    fun clearNotificationsForApp(packageName: String) {
        activeNotifications
            .filter { it.packageName == packageName }
            .forEach { cancelNotification(it.key) }
    }
    
    fun replyToNotification(notificationId: Int, message: String) {
        // Requires Notification.Action.REPLY action
        // Implementation depends on the specific notification
    }
    
    // ==================== UTILITY ====================
    
    private fun getAppName(packageName: String): String {
        return try {
            val packageManager = packageManager
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }
    }
    
    fun addAllowedApp(packageName: String) {
        allowedApps.add(packageName)
    }
    
    fun removeAllowedApp(packageName: String) {
        allowedApps.remove(packageName)
    }
    
    fun blockApp(packageName: String) {
        blockedApps.add(packageName)
    }
    
    fun unblockApp(packageName: String) {
        blockedApps.remove(packageName)
    }
}

// Notification data class
data class NotificationInfo(
    val id: Int,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val postTime: Long
)
