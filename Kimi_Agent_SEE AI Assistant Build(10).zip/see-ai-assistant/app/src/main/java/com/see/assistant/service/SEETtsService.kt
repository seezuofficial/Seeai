package com.see.assistant.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.see.assistant.utils.Logger

/**
 * SEETtsService - Custom Text-to-Speech service
 * 
 * This service can be extended to provide custom TTS functionality
 * or integrate with third-party TTS engines.
 */
class SEETtsService : Service() {
    
    private val TAG = "SEETtsService"
    private val binder = LocalBinder()
    
    inner class LocalBinder : Binder() {
        fun getService(): SEETtsService = this@SEETtsService
    }
    
    override fun onCreate() {
        super.onCreate()
        Logger.d(TAG, "🔊 SEETtsService created")
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Logger.d(TAG, "▶️ SEETtsService started")
        return START_STICKY
    }
    
    override fun onBind(intent: Intent): IBinder = binder
    
    override fun onDestroy() {
        super.onDestroy()
        Logger.d(TAG, "👋 SEETtsService destroyed")
    }
}
