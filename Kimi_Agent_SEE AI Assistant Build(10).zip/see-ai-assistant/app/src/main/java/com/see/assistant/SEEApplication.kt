package com.see.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Configuration
import androidx.work.WorkManager
import com.see.assistant.modules.*
import com.see.assistant.utils.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * SEE AI Assistant - Main Application Class
 * 
 * Yeh app ka entry point hai. Saare modules yahan initialize hote hain.
 * 
 * Features:
 * - Dependency injection container
 * - Notification channels setup
 * - Module initialization
 * - Crash handling
 */
class SEEApplication : Application(), Configuration.Provider {

    // Coroutine scope for app-level operations
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // Core Modules - Lazy initialization
    lateinit var wakeWordModule: WakeWordModule
        private set
    
    lateinit var voiceRecognitionModule: VoiceRecognitionModule
        private set
    
    lateinit var commandProcessor: CommandProcessor
        private set
    
    lateinit var actionExecutor: ActionExecutor
        private set
    
    lateinit var textToSpeechModule: TextToSpeechModule
        private set
    
    lateinit var settingsManager: SettingsManager
        private set
    
    lateinit var memoryManager: MemoryManager
        private set
    
    lateinit var uiOverlayManager: UIOverlayManager
        private set
    
    companion object {
        private const val TAG = "SEEApplication"
        
        @Volatile
        private var instance: SEEApplication? = null
        
        fun getInstance(): SEEApplication {
            return instance ?: throw IllegalStateException("Application not initialized")
        }
        
        fun getContext(): Context {
            return getInstance().applicationContext
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        Logger.i(TAG, "🚀 SEE AI Assistant initializing...")
        
        // Initialize crash handler
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Logger.e(TAG, "💥 Crash on thread ${thread.name}", throwable)
            // Could send to crash reporting service
        }
        
        // Create notification channels
        createNotificationChannels()
        
        // Initialize modules
        initializeModules()
        
        Logger.i(TAG, "✅ SEE AI Assistant initialized successfully")
    }
    
    private fun initializeModules() {
        applicationScope.launch {
            try {
                // 1. Settings Manager - sabse pehle chahiye
                settingsManager = SettingsManager(this@SEEApplication)
                settingsManager.initialize()
                Logger.d(TAG, "⚙️ SettingsManager initialized")
                
                // 2. Memory Manager
                memoryManager = MemoryManager(this@SEEApplication)
                memoryManager.initialize()
                Logger.d(TAG, "🧠 MemoryManager initialized")
                
                // 3. Text-to-Speech
                textToSpeechModule = TextToSpeechModule(this@SEEApplication)
                textToSpeechModule.initialize()
                Logger.d(TAG, "🔊 TextToSpeechModule initialized")
                
                // 4. Voice Recognition (Offline + Online)
                voiceRecognitionModule = VoiceRecognitionModule(this@SEEApplication)
                voiceRecognitionModule.initialize()
                Logger.d(TAG, "🎤 VoiceRecognitionModule initialized")
                
                // 5. Wake Word Detection
                wakeWordModule = WakeWordModule(this@SEEApplication)
                wakeWordModule.initialize()
                Logger.d(TAG, "👂 WakeWordModule initialized")
                
                // 6. Action Executor
                actionExecutor = ActionExecutor(this@SEEApplication)
                actionExecutor.initialize()
                Logger.d(TAG, "⚡ ActionExecutor initialized")
                
                // 7. Command Processor
                commandProcessor = CommandProcessor(
                    this@SEEApplication,
                    voiceRecognitionModule,
                    actionExecutor,
                    textToSpeechModule
                )
                commandProcessor.initialize()
                Logger.d(TAG, "🧩 CommandProcessor initialized")
                
                // 8. UI Overlay Manager
                uiOverlayManager = UIOverlayManager(this@SEEApplication)
                Logger.d(TAG, "🎨 UIOverlayManager initialized")
                
                // Welcome message
                launch(Dispatchers.Main) {
                    textToSpeechModule.speak("Hello Seezuu! Main ready hoon. Boliye kya karna hai?")
                }
                
            } catch (e: Exception) {
                Logger.e(TAG, "❌ Module initialization failed", e)
            }
        }
    }
    
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Main Service Channel
            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE,
                "SEE Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background service for wake word detection"
                setShowBadge(false)
            }
            
            // Command Channel
            val commandChannel = NotificationChannel(
                CHANNEL_COMMANDS,
                "Voice Commands",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for command execution"
                enableVibration(true)
            }
            
            // Reminders Channel
            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDERS,
                "Reminders & Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Reminder and alarm notifications"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }
            
            // General Channel
            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                "General Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "General notifications from SEE"
            }
            
            notificationManager.createNotificationChannels(listOf(
                serviceChannel,
                commandChannel,
                reminderChannel,
                generalChannel
            ))
            
            Logger.d(TAG, "📢 Notification channels created")
        }
    }
    
    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
    }
    
    override fun onTerminate() {
        super.onTerminate()
        // Cleanup
        if (::textToSpeechModule.isInitialized) {
            textToSpeechModule.shutdown()
        }
        if (::voiceRecognitionModule.isInitialized) {
            voiceRecognitionModule.shutdown()
        }
        if (::wakeWordModule.isInitialized) {
            wakeWordModule.shutdown()
        }
        Logger.i(TAG, "👋 SEE AI Assistant terminated")
    }
}

// Notification Channel IDs
const val CHANNEL_SERVICE = "see_service_channel"
const val CHANNEL_COMMANDS = "see_commands_channel"
const val CHANNEL_REMINDERS = "see_reminders_channel"
const val CHANNEL_GENERAL = "see_general_channel"
