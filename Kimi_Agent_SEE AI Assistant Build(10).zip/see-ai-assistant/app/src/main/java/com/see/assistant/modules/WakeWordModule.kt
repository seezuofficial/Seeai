package com.see.assistant.modules

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicBoolean

/**
 * WakeWordModule - Offline wake word detection using TensorFlow Lite
 * 
 * Wake words supported:
 * - "Hey SEE"
 * - "Hello SEE"
 * 
 * Features:
 * - Continuous listening in background
 * - Low power consumption
 * - Adjustable sensitivity
 * - Noise filtering
 */
class WakeWordModule(private val context: Context) {
    
    private val TAG = "WakeWordModule"
    
    // State
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening
    
    private val _isModelLoaded = MutableStateFlow(false)
    val isModelLoaded: StateFlow<Boolean> = _isModelLoaded
    
    // Audio
    private var audioRecord: AudioRecord? = null
    private var interpreter: Interpreter? = null
    private val isRunning = AtomicBoolean(false)
    
    // Audio Configuration
    private val sampleRate = 16000
    private val bufferSize = 16000 // 1 second of audio
    private val recordingBufferSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    ) * 2
    
    // Coroutine
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    
    // Callback
    private var onWakeWordDetected: (() -> Unit)? = null
    
    // Settings
    private var sensitivity = 0.7f
    private var wakeWordPhrase = "hey see"
    
    companion object {
        const val MODEL_FILE = "wake_word_model.tflite"
        const val CONFIDENCE_THRESHOLD = 0.75f
    }
    
    suspend fun initialize() {
        Logger.d(TAG, "👂 Initializing WakeWordModule")
        
        // Load settings
        val settings = SEEApplication.getInstance().settingsManager
        sensitivity = settings.getWakeWordSensitivity().first()
        wakeWordPhrase = settings.getWakeWordPhrase().first()
        
        // Load TFLite model
        loadModel()
        
        Logger.d(TAG, "✅ WakeWordModule initialized (sensitivity: $sensitivity)")
    }
    
    private suspend fun loadModel() {
        withContext(Dispatchers.IO) {
            try {
                // Check if model exists in assets
                val assetManager = context.assets
                val modelFile = assetManager.open(MODEL_FILE)
                
                // Load the model
                val modelBuffer = loadModelFile()
                
                val options = Interpreter.Options().apply {
                    setNumThreads(2)
                    useNNAPI(true) // Use Neural Network API for acceleration
                }
                
                interpreter = Interpreter(modelBuffer, options)
                _isModelLoaded.value = true
                
                Logger.i(TAG, "🧠 Wake word model loaded successfully")
                
            } catch (e: Exception) {
                Logger.e(TAG, "❌ Failed to load wake word model", e)
                // Fallback to simple keyword detection
                _isModelLoaded.value = false
            }
        }
    }
    
    private fun loadModelFile(): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd(MODEL_FILE)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }
    
    fun setWakeWordCallback(callback: () -> Unit) {
        onWakeWordDetected = callback
    }
    
    fun startListening() {
        if (isRunning.get()) {
            Logger.w(TAG, "Already listening")
            return
        }
        
        scope.launch {
            try {
                startAudioRecording()
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to start listening", e)
            }
        }
    }
    
    fun stopListening() {
        isRunning.set(false)
        _isListening.value = false
        
        try {
            audioRecord?.apply {
                stop()
                release()
            }
            audioRecord = null
        } catch (e: Exception) {
            Logger.e(TAG, "Error stopping audio record", e)
        }
        
        Logger.d(TAG, "🛑 Wake word listening stopped")
    }
    
    private suspend fun startAudioRecording() {
        withContext(Dispatchers.IO) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                recordingBufferSize
            )
            
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Logger.e(TAG, "AudioRecord initialization failed")
                return@withContext
            }
            
            audioRecord?.startRecording()
            isRunning.set(true)
            _isListening.value = true
            
            Logger.i(TAG, "🎙️ Wake word listening started")
            
            val audioBuffer = ShortArray(bufferSize)
            
            while (isRunning.get()) {
                val readResult = audioRecord?.read(audioBuffer, 0, bufferSize) ?: 0
                
                if (readResult > 0) {
                    processAudio(audioBuffer)
                }
            }
        }
    }
    
    private fun processAudio(audioData: ShortArray) {
        // Pre-process audio
        val processedAudio = preprocessAudio(audioData)
        
        // Run inference
        if (_isModelLoaded.value) {
            val confidence = runInference(processedAudio)
            
            if (confidence > CONFIDENCE_THRESHOLD * sensitivity) {
                onWakeWordDetected()
            }
        } else {
            // Fallback: Simple energy-based detection with keyword matching
            fallbackDetection(audioData)
        }
    }
    
    private fun preprocessAudio(audioData: ShortArray): FloatArray {
        // Convert to float and normalize
        val floatData = FloatArray(audioData.size)
        
        for (i in audioData.indices) {
            floatData[i] = audioData[i] / 32768.0f
        }
        
        // Apply pre-emphasis filter
        val preEmphasis = 0.97f
        for (i in floatData.size - 1 downTo 1) {
            floatData[i] -= preEmphasis * floatData[i - 1]
        }
        
        return floatData
    }
    
    private fun runInference(audioData: FloatArray): Float {
        return try {
            val inputBuffer = arrayOf(audioData)
            val outputBuffer = Array(1) { FloatArray(1) }
            
            interpreter?.run(inputBuffer, outputBuffer)
            
            outputBuffer[0][0]
        } catch (e: Exception) {
            Logger.e(TAG, "Inference error", e)
            0f
        }
    }
    
    private var consecutiveDetections = 0
    private val requiredConsecutiveDetections = 3
    
    private fun fallbackDetection(audioData: ShortArray) {
        // Simple energy detection + pattern matching
        val energy = calculateEnergy(audioData)
        
        if (energy > 500) { // Threshold for speech
            // Check for "SEE" pattern in audio
            if (detectSEEPattern(audioData)) {
                consecutiveDetections++
                
                if (consecutiveDetections >= requiredConsecutiveDetections) {
                    consecutiveDetections = 0
                    onWakeWordDetected?.invoke()
                }
            } else {
                consecutiveDetections = 0
            }
        }
    }
    
    private fun calculateEnergy(audioData: ShortArray): Double {
        var sum = 0.0
        for (sample in audioData) {
            sum += sample * sample
        }
        return sum / audioData.size
    }
    
    private fun detectSEEPattern(audioData: ShortArray): Boolean {
        // Simplified pattern detection for "SEE" sound
        // Look for high-frequency components characteristic of "S" and "E" sounds
        
        val frameSize = 400 // 25ms frames
        val frames = audioData.size / frameSize
        
        var highFreqEnergy = 0.0
        var totalEnergy = 0.0
        
        for (i in 0 until frames) {
            val frame = audioData.copyOfRange(i * frameSize, (i + 1) * frameSize)
            val energy = calculateEnergy(frame)
            totalEnergy += energy
            
            // Simple high-pass filter approximation
            for (j in 1 until frame.size) {
                val diff = frame[j] - frame[j - 1]
                highFreqEnergy += diff * diff
            }
        }
        
        // "SEE" has high frequency content
        val ratio = if (totalEnergy > 0) highFreqEnergy / totalEnergy else 0.0
        return ratio > 0.3
    }
    
    fun updateSensitivity(newSensitivity: Float) {
        sensitivity = newSensitivity.coerceIn(0.1f, 1.0f)
        Logger.d(TAG, "Sensitivity updated to: $sensitivity")
    }
    
    fun updateWakeWordPhrase(phrase: String) {
        wakeWordPhrase = phrase.lowercase()
        Logger.d(TAG, "Wake word phrase updated to: $wakeWordPhrase")
    }
    
    fun shutdown() {
        stopListening()
        scope.cancel()
        interpreter?.close()
        Logger.d(TAG, "👋 WakeWordModule shutdown")
    }
}

/**
 * SimplePorcupineWakeWord - Alternative wake word detector
 * Can be used if TensorFlow model is not available
 */
class SimplePorcupineWakeWord(private val context: Context) {
    
    private val TAG = "SimplePorcupine"
    
    // Keyword templates (simplified MFCC-like features)
    private val keywordTemplates = mapOf(
        "hey see" to listOf(
            floatArrayOf(0.5f, 0.3f, 0.8f, 0.6f, 0.4f),
            floatArrayOf(0.4f, 0.4f, 0.7f, 0.7f, 0.5f)
        ),
        "hello see" to listOf(
            floatArrayOf(0.6f, 0.4f, 0.7f, 0.5f, 0.6f),
            floatArrayOf(0.5f, 0.5f, 0.6f, 0.6f, 0.7f)
        )
    )
    
    fun detect(audioFeatures: FloatArray, keyword: String): Float {
        val templates = keywordTemplates[keyword] ?: return 0f
        
        var maxConfidence = 0f
        for (template in templates) {
            val similarity = cosineSimilarity(audioFeatures, template)
            if (similarity > maxConfidence) {
                maxConfidence = similarity
            }
        }
        
        return maxConfidence
    }
    
    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dotProduct = 0f
        var normA = 0f
        var normB = 0f
        
        val minLength = minOf(a.size, b.size)
        for (i in 0 until minLength) {
            dotProduct += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        
        return if (normA > 0 && normB > 0) {
            dotProduct / (kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB))
        } else 0f
    }
}
