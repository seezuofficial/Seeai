package com.see.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.see.assistant.*
import com.see.assistant.modules.*
import com.see.assistant.ui.MainActivity
import com.see.assistant.utils.Logger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/**
 * SEECoreService - Main background service
 * 
 * Ye service hamesha background mein chalti hai aur:
 * - Wake word detection manage karti hai
 * - Voice commands process karti hai
 * - Floating UI ko control karti hai
 */
class SEECoreService : Service() {
    
    private val TAG = "SEECoreService"
    
    // Binder for activity communication
    private val binder = LocalBinder()
    
    // Modules
    private lateinit var wakeWordModule: WakeWordModule
    private lateinit var voiceRecognition: VoiceRecognitionModule
    private lateinit var commandProcessor: CommandProcessor
    private lateinit var textToSpeech: TextToSpeechModule
    private lateinit var uiOverlayManager: UIOverlayManager
    private lateinit var settingsManager: SettingsManager
    
    // Wake lock for background operation
    private var wakeLock: PowerManager.WakeLock? = null
    
    // Coroutine scope
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // Service state
    private var isServiceRunning = false
    
    inner class LocalBinder : Binder() {
        fun getService(): SEECoreService = this@SEECoreService
    }
    
    override fun onCreate() {
        super.onCreate()
        Logger.i(TAG, "🚀 SEECoreService created")
        
        // Initialize modules from application
        val app = SEEApplication.getInstance()
        wakeWordModule = app.wakeWordModule
        voiceRecognition = app.voiceRecognitionModule
        commandProcessor = app.commandProcessor
        textToSpeech = app.textToSpeechModule
        uiOverlayManager = app.uiOverlayManager
        settingsManager = app.settingsManager
        
        // Acquire wake lock
        acquireWakeLock()
        
        // Setup callbacks
        setupCallbacks()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Logger.d(TAG, "▶️ SEECoreService started")
        
        // Start as foreground service
        startForeground(NOTIFICATION_ID, createNotification())
        
        // Start wake word detection if enabled
        serviceScope.launch {
            val wakeWordEnabled = settingsManager.isWakeWordEnabled().first()
            if (wakeWordEnabled) {
                startWakeWordDetection()
            }
        }
        
        isServiceRunning = true
        
        return START_STICKY // Restart if killed
    }
    
    override fun onBind(intent: Intent): IBinder {
        return binder
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Logger.i(TAG, "👋 SEECoreService destroyed")
        
        isServiceRunning = false
        
        // Stop wake word detection
        wakeWordModule.stopListening()
        
        // Release wake lock
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        
        // Cancel coroutines
        serviceScope.cancel()
    }
    
    // ==================== NOTIFICATION ====================
    
    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("SEE Assistant")
            .setContentText("Listening for 'Hey SEE'")
            .setSmallIcon(R.drawable.ic_assistant)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(
                R.drawable.ic_mic,
                "Activate",
                createActionPendingIntent(ACTION_ACTIVATE)
            )
            .addAction(
                R.drawable.ic_settings,
                "Settings",
                createActionPendingIntent(ACTION_SETTINGS)
            )
            .build()
    }
    
    private fun createActionPendingIntent(action: String): PendingIntent {
        val intent = Intent(this, SEECoreService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )
    }
    
    private fun updateNotification(text: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setContentTitle("SEE Assistant")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_assistant)
            .setOngoing(true)
            .build()
        
        startForeground(NOTIFICATION_ID, notification)
    }
    
    // ==================== WAKE WORD ====================
    
    private fun startWakeWordDetection() {
        Logger.i(TAG, "👂 Starting wake word detection")
        
        wakeWordModule.setWakeWordCallback {
            onWakeWordDetected()
        }
        
        wakeWordModule.startListening()
        updateNotification("Listening for 'Hey SEE'")
    }
    
    private fun onWakeWordDetected() {
        Logger.i(TAG, "🎯 Wake word detected!")
        
        serviceScope.launch {
            // Vibrate
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    android.os.VibrationEffect.createOneShot(
                        100,
                        android.os.VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            }
            
            // Show floating UI
            uiOverlayManager.show()
            uiOverlayManager.startListeningAnimation()
            
            // Speak acknowledgment
            val tone = settingsManager.getTone().first()
            val userName = settingsManager.getUserName().first()
            val response = when (tone) {
                Tones.FRIENDLY -> "Haan $userName, boliye"
                Tones.FUNNY -> "Haan bolo $userName, sun raha hoon!"
                Tones.ROMANTIC -> "Haan jaan, bolo na..."
                Tones.PROFESSIONAL -> "Yes $userName, I'm listening."
                else -> "Haan bolo"
            }
            textToSpeech.speak(response)
            
            // Start voice recognition
            startVoiceRecognition()
        }
    }
    
    // ==================== VOICE RECOGNITION ====================
    
    private fun startVoiceRecognition() {
        updateNotification("Listening...")
        
        voiceRecognition.startListening(
            onResult = { text ->
                serviceScope.launch {
                    uiOverlayManager.stopListeningAnimation()
                    uiOverlayManager.showThinkingAnimation()
                    
                    // Process command
                    commandProcessor.processTextCommand(text)
                    
                    delay(1000)
                    uiOverlayManager.hide()
                    
                    updateNotification("Listening for 'Hey SEE'")
                }
            },
            onPartialResult = { partial ->
                // Update UI with partial result
            },
            onError = { error ->
                serviceScope.launch {
                    uiOverlayManager.stopListeningAnimation()
                    textToSpeech.speak("Sorry, samajh nahi aaya. Phir se bolo.")
                    uiOverlayManager.hide()
                    updateNotification("Listening for 'Hey SEE'")
                }
            }
        )
    }
    
    // ==================== CALLBACKS ====================
    
    private fun setupCallbacks() {
        // UI Overlay callbacks
        uiOverlayManager.onOrbClick = {
            serviceScope.launch {
                if (!voiceRecognition.isListening.value) {
                    uiOverlayManager.startListeningAnimation()
                    startVoiceRecognition()
                }
            }
        }
        
        uiOverlayManager.onOrbLongClick = {
            // Open settings
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }
    }
    
    // ==================== WAKE LOCK ====================
    
    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SEE:CoreServiceWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // 10 minutes
        }
    }
    
    // ==================== PUBLIC METHODS ====================
    
    fun activateAssistant() {
        serviceScope.launch {
            uiOverlayManager.show()
            uiOverlayManager.startListeningAnimation()
            startVoiceRecognition()
        }
    }
    
    fun isRunning(): Boolean = isServiceRunning
    
    fun stopWakeWordDetection() {
        wakeWordModule.stopListening()
        updateNotification("Wake word detection paused")
    }
    
    fun restartWakeWordDetection() {
        startWakeWordDetection()
    }
    
    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_ACTIVATE = "com.see.assistant.ACTIVATE"
        const val ACTION_SETTINGS = "com.see.assistant.SETTINGS"
        const val ACTION_STOP = "com.see.assistant.STOP"
        
        fun startService(context: Context) {
            val intent = Intent(context, SEECoreService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        
        fun stopService(context: Context) {
            val intent = Intent(context, SEECoreService::class.java)
            context.stopService(intent)
        }
    }
}
